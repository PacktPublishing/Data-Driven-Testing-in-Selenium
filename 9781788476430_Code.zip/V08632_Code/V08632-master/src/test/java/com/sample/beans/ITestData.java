package com.sample.beans;

public interface ITestData {
    Object[][] getData();
}
